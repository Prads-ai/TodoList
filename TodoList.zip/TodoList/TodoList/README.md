# TodoList
A simple todo list created with React for Prifina
